PixelCraft Studio: all files

pixelcraft-website/index.html   Main website (home, services, portfolio, pricing, reviews, contact, admin).
                                NOTE: its database/admin features only work on the Claude-hosted version,
                                because they use Claude's built-in storage. As a plain file, the design and
                                contact buttons work, but forms and the admin panel will not save data.
logo/pixelcraft-logo.svg        Logo (vector).
auth-preview/preview.html       Sign In / Sign Up modal preview with 3D animation and glow text (visual only).
pixelcraft-auth-supabase/       Real sign up / sign in / dashboards for Cloudflare Pages + Supabase.
                                Start with its README.md.
