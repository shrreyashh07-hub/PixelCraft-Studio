# PixelCraft Studio: Supabase Auth + Dashboards (Cloudflare Pages)

Real sign up, email verification, sign in, password reset, logout, user dashboard and a separate admin dashboard.
Passwords are never stored by this code: Supabase Auth hashes them. All data access is limited by Row Level Security in `supabase/schema.sql`.

## 1. Supabase (about 10 minutes)
1. Create a project at supabase.com.
2. SQL Editor: paste and run all of `supabase/schema.sql`.
3. Authentication > Providers > Email: keep **Confirm email** ON (this is what sends verification emails).
4. Authentication > URL Configuration: set **Site URL** to your live URL (e.g. `https://pixelcraft.pages.dev`) and add Redirect URLs: `https://YOUR-DOMAIN/auth.html` and `https://YOUR-DOMAIN/dashboard.html`.
5. Recommended: Authentication > SMTP Settings, add your own email provider. Supabase's built-in email sender is heavily rate-limited and only for testing.
6. Settings > API: copy the **Project URL** and the public **anon / publishable** key. Never copy the service_role / secret key into anything here.

## 2. Cloudflare Pages
1. Push this folder to GitHub, then Cloudflare > Workers & Pages > Create > Pages > Connect to Git.
2. Build command: `node build.js`  Build output directory: `dist`
3. Environment variables (Production and Preview): `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and optionally `GOOGLE_ENABLED=true`.
   The build stops with an error if either is missing or if a secret key is used.
4. Deploy. `build.js` writes `config.js` and puts your Supabase address into the security headers (`_headers`).

## 3. Make yourself admin
1. Open `/auth.html#signup`, create your account, click the link in the verification email.
2. In the Supabase SQL Editor run: `update public.profiles set role = 'admin' where email = 'youryash23@gmail.com';`
3. Sign in at `/admin.html`. Anyone without `role = 'admin'` is signed out there, and RLS blocks them from admin data anyway.

## 4. Optional: Google sign in
Only set `GOOGLE_ENABLED=true` after enabling Google in Supabase (Authentication > Providers > Google) with your Google OAuth client ID and secret. Without that, the button stays hidden.

## 5. Add the nav to your main site
In your main site header add `<div id="authNav"></div>`, then before `</body>`:
`<script src="config.js"></script><script type="module">import { renderNav } from './js/auth.js'; renderNav();</script>`
Also copy `style.css` rules for `.btn`, `.dd`, `.av`, `.ddm` (or link style.css). Visitors then see Sign In / Sign Up, and after login a profile icon with Profile, My Projects, Settings, Logout.

## Pages
`auth.html` sign in / sign up / forgot / reset (hash-switched) · `dashboard.html` user area · `admin.html` admin login + dashboard.

## Security notes
- Only the public anon key is in the browser. RLS plus column-level grants decide what each user can read or write; users cannot change their role, request status or anyone else's data.
- Dashboard pages verify the session with Supabase on load; the real enforcement is RLS on the server.
- Reset emails always show the same message, so attackers can't discover which emails have accounts.
- `_headers` sets a strict Content-Security-Policy. Supabase JS loads from a pinned jsDelivr version.
- Turn on Supabase Auth CAPTCHA and rate limits (Authentication > Rate Limits / Attack Protection) before launch.
