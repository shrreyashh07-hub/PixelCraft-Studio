// Cloudflare Pages build: copies /public to /dist and writes config.js from environment variables.
const fs = require('fs');
const { SUPABASE_URL: url, SUPABASE_ANON_KEY: key, GOOGLE_ENABLED: google } = process.env;
const fail = m => { console.error('\nBUILD ERROR: ' + m + '\n'); process.exit(1); };
if (!url || !key) fail('Set SUPABASE_URL and SUPABASE_ANON_KEY in Cloudflare Pages > Settings > Environment variables.');
if (!/^https:\/\/[a-z0-9-]+\.supabase\.(co|in)$/i.test(url) && !/^https:\/\//.test(url)) fail('SUPABASE_URL must be an https URL.');
if (key.startsWith('sb_secret_')) fail('That is a SECRET key. Use only the public anon/publishable key.');
if (!key.startsWith('sb_publishable_')) {
  try { const p = JSON.parse(Buffer.from(key.split('.')[1], 'base64url').toString()); if (p.role !== 'anon') throw 0; }
  catch { fail('SUPABASE_ANON_KEY must be the public "anon" key. Never use the service_role key in frontend code.'); }
}
fs.rmSync('dist', { recursive: true, force: true });
fs.cpSync('public', 'dist', { recursive: true });
const host = new URL(url).host;
fs.writeFileSync('dist/config.js', 'window.PX_CONFIG=' + JSON.stringify({ url, key, google: google === 'true' ? 'true' : 'false' }) + ';');
const h = fs.readFileSync('dist/_headers', 'utf8').replaceAll('__SUPABASE_URL__', url).replaceAll('__SUPABASE_HOST__', host);
fs.writeFileSync('dist/_headers', h);
console.log('Built dist/ for ' + host);
