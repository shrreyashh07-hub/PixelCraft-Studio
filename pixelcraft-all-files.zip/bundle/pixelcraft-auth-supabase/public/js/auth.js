import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm';
const C = window.PX_CONFIG;
const mk = () => createClient(C.url, C.key, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true,
  storage: localStorage.getItem('px_remember') === '0' ? sessionStorage : localStorage } });
export let sb = mk();
export const setRemember = v => { localStorage.setItem('px_remember', v ? '1' : '0'); sb = mk(); };
export const $ = (s, r = document) => r.querySelector(s);
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const msg = (el, t, type = 'er') => { el.className = 'alert ' + type; el.textContent = t; el.hidden = !t; };
export const V = {
  email: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) && v.length <= 254,
  phone: v => /^\+?[0-9 ()-]{7,20}$/.test(v),
  name: v => v.trim().length >= 2 && v.length <= 100,
  pw: v => v.length >= 8 && v.length <= 72 && /[A-Za-z]/.test(v) && /\d/.test(v)
};
export const PWMSG = 'Password must be 8+ characters and include at least one letter and one number.';
export const money = n => '₹' + Number(n || 0).toLocaleString('en-IN');
export const date = d => new Date(d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
export async function session() { const { data } = await sb.auth.getSession(); return data.session; }
export async function profile(uid) { const { data } = await sb.from('profiles').select('*').eq('id', uid).single(); return data; }
export async function logout() { await sb.auth.signOut(); location.href = 'auth.html#signin'; }
// Verifies the token with the Supabase server (not just the local copy) before showing protected pages.
export async function guard() {
  const { data: { user } = {}, error } = await sb.auth.getUser();
  if (error || !user) { location.replace('auth.html?next=' + encodeURIComponent(location.pathname.split('/').pop() || 'dashboard.html')); return null; }
  return user;
}
export async function renderNav() {
  const box = $('#authNav'); if (!box) return;
  const s = await session();
  if (!s) { box.innerHTML = '<a class="btn o s" href="auth.html#signin">Sign In</a><a class="btn s" href="auth.html#signup">Sign Up</a>'; return; }
  const p = await profile(s.user.id), n = p?.full_name || s.user.email, adm = p?.role === 'admin';
  box.innerHTML = `<div class="dd"><button class="av" id="ddb" aria-haspopup="true" aria-expanded="false" aria-label="Account menu">${esc(n[0].toUpperCase())}</button>
  <div class="ddm" id="ddm" hidden><div class="ddh"><b>${esc(n)}</b><small>${esc(s.user.email)}</small></div>
  <a href="dashboard.html#profile">Profile</a><a href="dashboard.html#projects">My Projects</a><a href="dashboard.html#settings">Settings</a>${adm ? '<a href="admin.html">Admin Panel</a>' : ''}<button id="lo">Logout</button></div></div>`;
  const m = $('#ddm'), b = $('#ddb');
  const set = o => { m.hidden = !o; b.setAttribute('aria-expanded', o); };
  b.onclick = e => { e.stopPropagation(); set(m.hidden); };
  document.addEventListener('click', e => { if (!m.contains(e.target)) set(false); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') set(false); });
  $('#lo').onclick = logout;
}
