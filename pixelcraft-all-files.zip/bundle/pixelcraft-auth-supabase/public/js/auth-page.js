import { sb, setRemember, $, msg, V, PWMSG, session, renderNav } from './auth.js';
const C = window.PX_CONFIG, q = new URLSearchParams(location.search), PANELS = ['signin', 'signup', 'forgot', 'reset'];
const go = p => { document.querySelectorAll('[data-p]').forEach(e => e.hidden = e.dataset.p !== p); history.replaceState(null, '', location.pathname + location.search + '#' + p); };
const next = () => q.get('next') === 'admin.html' ? 'admin.html' : 'dashboard.html'; // whitelist: no open redirects
document.addEventListener('click', e => {
  const t = e.target.closest('[data-go]'); if (t) { e.preventDefault(); go(t.dataset.go); }
  const b = e.target.closest('[data-eye]'); if (b) { const i = $('#' + b.dataset.eye); i.type = i.type === 'password' ? 'text' : 'password'; b.textContent = i.type === 'password' ? 'Show' : 'Hide'; }
});
const h = location.hash.slice(1);
go(q.get('mode') === 'reset' ? 'reset' : PANELS.includes(h) && h !== 'reset' ? h : 'signin');
sb.auth.onAuthStateChange(ev => { if (ev === 'PASSWORD_RECOVERY') go('reset'); });
if (C.google === 'true') { $('#google').hidden = false; $('#orG').hidden = false; }
renderNav();

const s = await session();
if (q.get('verified') === '1' && s) { msg($('#signinMsg'), 'Email verified! Taking you to your dashboard…', 'ok'); setTimeout(() => location.href = 'dashboard.html', 1500); }
else if (s && q.get('mode') !== 'reset') location.replace(next());

$('#fSignin').addEventListener('submit', async e => {
  e.preventDefault(); const m = $('#signinMsg'), email = $('#siEmail').value.trim(), pw = $('#siPw').value;
  if (!V.email(email)) return msg(m, 'Enter a valid email address.');
  if (!pw) return msg(m, 'Enter your password.');
  const btn = e.submitter; btn.disabled = true; setRemember($('#remember').checked);
  const { error } = await sb.auth.signInWithPassword({ email, password: pw }); btn.disabled = false;
  if (error) {
    if (/not confirmed/i.test(error.message)) { msg(m, 'Please verify your email first. Check your inbox (and spam folder).'); $('#resend').hidden = false; }
    else msg(m, 'Invalid email or password.');
    return;
  }
  location.href = next();
});
$('#resend').onclick = async () => {
  const m = $('#signinMsg'), email = $('#siEmail').value.trim(); if (!V.email(email)) return msg(m, 'Enter your email above first.');
  const { error } = await sb.auth.resend({ type: 'signup', email, options: { emailRedirectTo: location.origin + '/auth.html?verified=1' } });
  msg(m, error ? 'Could not resend right now. Please try again in a minute.' : 'Verification email sent. Check your inbox.', error ? 'er' : 'ok');
};
$('#google').onclick = () => sb.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: location.origin + '/dashboard.html' } });

$('#fSignup').addEventListener('submit', async e => {
  e.preventDefault(); const m = $('#signupMsg');
  const name = $('#suName').value.trim(), email = $('#suEmail').value.trim(), phone = $('#suPhone').value.trim(), pw = $('#suPw').value;
  if (!V.name(name)) return msg(m, 'Enter your full name.');
  if (!V.email(email)) return msg(m, 'Enter a valid email address.');
  if (!V.phone(phone)) return msg(m, 'Enter a valid phone number, e.g. +91 8092625918.');
  if (!V.pw(pw)) return msg(m, PWMSG);
  if (pw !== $('#suPw2').value) return msg(m, 'Passwords do not match.');
  if (!$('#terms').checked) return msg(m, 'Please accept the Terms & Conditions.');
  const btn = e.submitter; btn.disabled = true;
  const { data, error } = await sb.auth.signUp({ email, password: pw, options: { data: { full_name: name, phone }, emailRedirectTo: location.origin + '/auth.html?verified=1' } });
  btn.disabled = false;
  if (error) return msg(m, /rate|limit/i.test(error.message) ? 'Too many attempts. Please wait a few minutes and try again.' : error.message);
  if (data.user && data.user.identities && data.user.identities.length === 0) return msg(m, 'An account with this email already exists. Try signing in or resetting your password.');
  e.target.reset(); msg(m, `Account created! We sent a verification link to ${email}. Verify your email, then sign in.`, 'ok');
});
$('#fForgot').addEventListener('submit', async e => {
  e.preventDefault(); const m = $('#forgotMsg'), email = $('#fgEmail').value.trim();
  if (!V.email(email)) return msg(m, 'Enter a valid email address.');
  const btn = e.submitter; btn.disabled = true;
  await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + '/auth.html?mode=reset' }); btn.disabled = false;
  msg(m, 'If an account exists for that email, a reset link is on its way.', 'ok'); // same message either way: no account enumeration
});
$('#fReset').addEventListener('submit', async e => {
  e.preventDefault(); const m = $('#resetMsg'), pw = $('#rsPw').value;
  if (!V.pw(pw)) return msg(m, PWMSG);
  if (pw !== $('#rsPw2').value) return msg(m, 'Passwords do not match.');
  const { error } = await sb.auth.updateUser({ password: pw });
  if (error) return msg(m, 'This reset link is invalid or has expired. Request a new one.');
  await sb.auth.signOut(); history.replaceState(null, '', 'auth.html'); go('signin'); msg($('#signinMsg'), 'Password updated. Please sign in with your new password.', 'ok');
});
