import { sb, setRemember, $, esc, msg, V, money, date, profile, logout, renderNav } from './auth.js';
const SL = ['pending', 'in_review', 'accepted', 'in_progress', 'completed', 'rejected'];
const flash = (t, type = 'ok') => { msg($('#m'), t, type); };
const tbl = (cols, rows, empty) => rows.length ? `<div class="tw"><table><thead><tr>${cols.map(c => `<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : `<p class="mu">${empty}</p>`;
let USERS = [];
async function isAdmin(uid) { const p = await profile(uid); return p?.role === 'admin'; }
async function start() {
  const { data: { user } = {} } = await sb.auth.getUser();
  if (user && await isAdmin(user.id)) { $('#login').hidden = true; $('#app').hidden = false; renderNav(); show(); return; }
  if (user) { await sb.auth.signOut(); msg($('#lm'), 'This account does not have admin access.'); }
  $('#app').hidden = true; $('#login').hidden = false;
}
$('#eye').onclick = () => { const i = $('#aPw'); i.type = i.type === 'password' ? 'text' : 'password'; $('#eye').textContent = i.type === 'password' ? 'Show' : 'Hide'; };
$('#fLogin').addEventListener('submit', async e => {
  e.preventDefault(); const m = $('#lm'), email = $('#aEmail').value.trim(), pw = $('#aPw').value;
  if (!V.email(email) || !pw) return msg(m, 'Enter your admin email and password.');
  setRemember(false); // admin sessions live only in this browser tab
  const { data, error } = await sb.auth.signInWithPassword({ email, password: pw });
  if (error) return msg(m, 'Invalid credentials.');
  if (!(await isAdmin(data.user.id))) { await sb.auth.signOut(); return msg(m, 'This account does not have admin access.'); }
  start();
});
$('#out').onclick = logout;

const views = {
  async users() {
    const { data = [] } = await sb.from('profiles').select('*').order('created_at', { ascending: false }); USERS = data;
    return '<h2>Registered Users</h2>' + tbl(['Name', 'Email', 'Phone', 'Role', 'Joined', ''], data.map(u => [esc(u.full_name), esc(u.email), esc(u.phone), `<span class="badge">${esc(u.role)}</span>`, date(u.created_at), `<button class="btn o s" data-notify="${u.id}">Send notice</button>`]), 'No users yet.') +
      '<p class="mu" style="margin-top:12px">Roles can only be changed in the Supabase SQL editor, so no one can be promoted from the website.</p>';
  },
  async requests() {
    const { data = [] } = await sb.from('project_requests').select('*, profiles(full_name,email)').order('created_at', { ascending: false });
    return '<h2>Project Requests</h2>' + tbl(['Client', 'Type', 'Budget', 'Details', 'Date', 'Status'], data.map(r => [esc(r.profiles?.full_name) + `<br><small class="mu">${esc(r.profiles?.email)}</small>`, esc(r.website_type) + (r.business_name ? '<br><small class="mu">' + esc(r.business_name) + '</small>' : ''), esc(r.budget), `<div style="white-space:normal;min-width:220px">${esc(r.details)}</div>`, date(r.created_at),
      `<select data-st="${r.id}" data-u="${r.user_id}">${SL.map(s => `<option ${s === r.status ? 'selected' : ''}>${s}</option>`).join('')}</select>`]), 'No requests yet.');
  },
  async orders() {
    const [o, u] = await Promise.all([sb.from('orders').select('*, profiles(full_name,email)').order('created_at', { ascending: false }), sb.from('profiles').select('id,full_name,email')]);
    USERS = u.data || [];
    return '<h2>Orders</h2>' + `<form id="fOrd" class="two" style="margin-bottom:18px"><label>Client<select id="oU">${USERS.map(x => `<option value="${x.id}">${esc(x.full_name || x.email)}</option>`).join('')}</select></label><label>Title<input id="oT" required maxlength="120"></label><label>Amount (₹)<input id="oA" type="number" min="0" step="0.01" required></label><label>Status<select id="oS"><option>unpaid</option><option>paid</option><option>refunded</option></select></label><button class="btn">Create Order</button></form>` +
      tbl(['Client', 'Order', 'Amount', 'Status', 'Date', ''], (o.data || []).map(x => [esc(x.profiles?.full_name || x.profiles?.email), esc(x.title), money(x.amount), `<select data-os="${x.id}">${['unpaid', 'paid', 'refunded'].map(s => `<option ${s === x.status ? 'selected' : ''}>${s}</option>`).join('')}</select>`, date(x.created_at), `<button class="btn d s" data-del="orders:${x.id}">Delete</button>`]), 'No orders yet.');
  },
  async portfolio() {
    const { data = [] } = await sb.from('portfolio_projects').select('*').order('created_at', { ascending: false });
    return '<h2>Portfolio</h2>' + `<form id="fPort" class="two" style="margin-bottom:18px"><label>Title<input id="tT" required maxlength="120"></label><label>Category<input id="tC" required maxlength="60"></label><label>Image URL (https)<input id="tI" type="url"></label><label>Live URL (https)<input id="tL" type="url"></label><label style="grid-column:1/-1">Description<textarea id="tD" rows="2" maxlength="600"></textarea></label><button class="btn">Add Project</button></form>` +
      tbl(['Title', 'Category', 'Live', ''], data.map(p => [esc(p.title), esc(p.category), p.live_url ? `<a href="${esc(p.live_url)}" target="_blank" rel="noopener noreferrer">Open</a>` : '', `<button class="btn d s" data-del="portfolio_projects:${p.id}">Delete</button>`]), 'No portfolio projects yet.');
  },
  async reviews() {
    const { data = [] } = await sb.from('reviews').select('*').order('created_at', { ascending: false });
    return '<h2>Reviews</h2>' + tbl(['Name', 'Rating', 'Review', 'Status', ''], data.map(r => [esc(r.name), '★'.repeat(r.rating), `<div style="white-space:normal;min-width:220px">${esc(r.body)}</div>`, `<span class="badge ${esc(r.status)}">${esc(r.status)}</span>`,
      `<button class="btn s" data-rv="approved:${r.id}">Approve</button> <button class="btn o s" data-rv="rejected:${r.id}">Reject</button> <button class="btn d s" data-del="reviews:${r.id}">Delete</button>`]), 'No reviews submitted yet.');
  },
  async inquiries() {
    const { data = [] } = await sb.from('inquiries').select('*').order('created_at', { ascending: false });
    return '<h2>Customer Inquiries</h2>' + tbl(['Name', 'Contact', 'Type / Budget', 'Details', 'Date', ''], data.map(i => [esc(i.name) + (i.business ? '<br><small class="mu">' + esc(i.business) + '</small>' : ''), `${esc(i.email)}<br><small class="mu">${esc(i.whatsapp)}</small>`, esc(i.website_type) + '<br><small class="mu">' + esc(i.budget) + '</small>', `<div style="white-space:normal;min-width:220px">${esc(i.details)}</div>`, date(i.created_at), `<button class="btn d s" data-del="inquiries:${i.id}">Delete</button>`]), 'No inquiries yet.');
  }
};
async function show() {
  const t = views[location.hash.slice(1)] ? location.hash.slice(1) : 'users';
  document.querySelectorAll('#side a').forEach(a => a.classList.toggle('on', a.hash === '#' + t));
  $('#view').innerHTML = '<p class="mu">Loading…</p>'; $('#view').innerHTML = await views[t]();
}
addEventListener('hashchange', () => $('#app').hidden || show());
const notify = async (user_id, title, body) => sb.from('notifications').insert({ user_id, title, body });
document.addEventListener('change', async e => {
  const st = e.target.dataset.st, os = e.target.dataset.os;
  if (st) { const { error } = await sb.from('project_requests').update({ status: e.target.value }).eq('id', st);
    if (error) return flash('Could not update status.', 'er'); await notify(e.target.dataset.u, 'Project status updated', 'Your project request is now: ' + e.target.value.replace('_', ' ') + '.'); flash('Status updated and client notified.'); }
  if (os) { const { error } = await sb.from('orders').update({ status: e.target.value }).eq('id', os); flash(error ? 'Could not update order.' : 'Order updated.', error ? 'er' : 'ok'); }
});
document.addEventListener('click', async e => {
  const b = e.target.closest('button'); if (!b || $('#app').hidden) return;
  if (b.dataset.del) { const [tb, id] = b.dataset.del.split(':'); if (!confirm('Delete this item permanently?')) return; const { error } = await sb.from(tb).delete().eq('id', id); flash(error ? 'Delete failed.' : 'Deleted.', error ? 'er' : 'ok'); show(); }
  if (b.dataset.rv) { const [status, id] = b.dataset.rv.split(':'); const { error } = await sb.from('reviews').update({ status }).eq('id', id); flash(error ? 'Update failed.' : 'Review ' + status + '.', error ? 'er' : 'ok'); show(); }
  if (b.dataset.notify) { const t = prompt('Message to send to this client:'); if (t && t.trim()) { const { error } = await notify(b.dataset.notify, 'Message from PixelCraft Studio', t.trim().slice(0, 500)); flash(error ? 'Could not send.' : 'Notice sent.', error ? 'er' : 'ok'); } }
});
document.addEventListener('submit', async e => {
  if (e.target.id === 'fOrd') { e.preventDefault(); const { error } = await sb.from('orders').insert({ user_id: $('#oU').value, title: $('#oT').value.trim(), amount: +$('#oA').value, status: $('#oS').value }); flash(error ? 'Could not create order.' : 'Order created.', error ? 'er' : 'ok'); show(); }
  if (e.target.id === 'fPort') { e.preventDefault(); const https = v => !v || /^https:\/\//.test(v);
    const row = { title: $('#tT').value.trim(), category: $('#tC').value.trim(), image_url: $('#tI').value.trim() || null, live_url: $('#tL').value.trim() || null, description: $('#tD').value.trim() || null };
    if (!https(row.image_url) || !https(row.live_url)) return flash('URLs must start with https://', 'er');
    const { error } = await sb.from('portfolio_projects').insert(row); flash(error ? 'Could not add project.' : 'Project added.', error ? 'er' : 'ok'); show(); }
});
sb.auth.onAuthStateChange(ev => { if (ev === 'SIGNED_OUT') { $('#app').hidden = true; $('#login').hidden = false; } });
start();
