import { sb, $, esc, msg, V, PWMSG, money, date, guard, profile, logout, renderNav } from './auth.js';
const user = await guard();
if (user) {
  $('#app').hidden = false; renderNav();
  const SL = { pending: 'Pending', in_review: 'In review', accepted: 'Accepted', in_progress: 'In progress', completed: 'Completed', rejected: 'Rejected' };
  const flash = (t, type = 'ok') => { msg($('#msg'), t, type); scrollTo({ top: 0, behavior: 'smooth' }); };
  let P = await profile(user.id);
  const first = () => (P?.full_name || user.email).split(' ')[0];
  const head = () => { $('#welcome').innerHTML = `Welcome, <span class="grad">${esc(first())}</span> 👋`; };
  head(); $('#verifyBanner').hidden = !!user.email_confirmed_at;
  $('#acct').textContent = `Signed in as ${user.email}${user.email_confirmed_at ? ' · email verified' : ' · email not verified'}`;

  async function loadAll() {
    const [pr, od, nt] = await Promise.all([
      sb.from('project_requests').select('*').order('created_at', { ascending: false }),
      sb.from('orders').select('*').order('created_at', { ascending: false }),
      sb.from('notifications').select('*').order('created_at', { ascending: false })]);
    const R = pr.data || [], O = od.data || [], N = nt.data || [], unread = N.filter(n => !n.is_read).length;
    $('#stats').innerHTML = [[R.length, 'Project requests'], [R.filter(r => ['accepted', 'in_progress'].includes(r.status)).length, 'In progress'], [O.length, 'Orders'], [unread, 'Unread notifications']].map(s => `<div class="stat"><b class="grad">${s[0]}</b><span>${s[1]}</span></div>`).join('');
    $('#nCount').hidden = !unread; $('#nCount').textContent = unread;
    $('#projList').innerHTML = R.length ? R.map(r => `<div class="it"><div><b>${esc(r.website_type)}</b>${r.business_name ? ' · ' + esc(r.business_name) : ''}<small>${esc(r.details.slice(0, 140))} · ${date(r.created_at)}</small></div><span class="badge ${esc(r.status)}">${SL[r.status] || esc(r.status)}</span></div>`).join('') : '<p class="mu">No project requests yet. Submit your first one below.</p>';
    $('#ordList').innerHTML = O.length ? O.map(o => `<div class="it"><div><b>${esc(o.title)}</b><small>${date(o.created_at)}</small></div><div><b>${money(o.amount)}</b> <span class="badge ${esc(o.status)}">${esc(o.status)}</span></div></div>`).join('') : '<p class="mu">No orders yet.</p>';
    $('#notList').innerHTML = N.length ? N.map(n => `<div class="it ${n.is_read ? '' : 'unread'}"><div><b>${esc(n.title)}</b><small>${esc(n.body || '')}</small></div><small>${date(n.created_at)}</small></div>`).join('') : '<p class="mu">You’re all caught up.</p>';
  }
  const fillProfile = () => { $('#pName').value = P?.full_name || ''; $('#pEmail').value = user.email; $('#pPhone').value = P?.phone || ''; };
  fillProfile(); await loadAll();

  const show = () => { const t = location.hash.slice(1) || 'overview'; let f = false;
    document.querySelectorAll('[data-s]').forEach(s => { const on = s.dataset.s === t; s.hidden = !on; f ||= on; });
    if (!f) { $('[data-s=overview]').hidden = false; }
    document.querySelectorAll('#side a').forEach(a => a.classList.toggle('on', a.hash === '#' + (f ? t : 'overview'))); };
  addEventListener('hashchange', show); show();

  $('#fProfile').addEventListener('submit', async e => { e.preventDefault();
    const full_name = $('#pName').value.trim(), phone = $('#pPhone').value.trim();
    if (!V.name(full_name)) return flash('Enter your full name.', 'er');
    if (!V.phone(phone)) return flash('Enter a valid phone number.', 'er');
    const { error } = await sb.from('profiles').update({ full_name, phone }).eq('id', user.id);
    if (error) return flash('Could not save your profile. Please try again.', 'er');
    P = await profile(user.id); head(); renderNav(); flash('Profile updated.'); });
  $('#fReq').addEventListener('submit', async e => { e.preventDefault();
    const details = $('#rDet').value.trim(); if (details.length < 10) return flash('Please describe your project (at least 10 characters).', 'er');
    const { error } = await sb.from('project_requests').insert({ website_type: $('#rType').value, budget: $('#rBudget').value, business_name: $('#rBiz').value.trim() || null, details });
    if (error) return flash('Could not submit your request. Please try again.', 'er');
    e.target.reset(); await loadAll(); flash('Request submitted! You can track its status here.'); });
  $('#markAll').onclick = async () => { await sb.from('notifications').update({ is_read: true }).eq('user_id', user.id).eq('is_read', false); loadAll(); };
  $('#eye').onclick = () => { const i = $('#npw'); i.type = i.type === 'password' ? 'text' : 'password'; $('#eye').textContent = i.type === 'password' ? 'Show' : 'Hide'; };
  $('#fPw').addEventListener('submit', async e => { e.preventDefault(); const pw = $('#npw').value;
    if (!V.pw(pw)) return flash(PWMSG, 'er'); if (pw !== $('#npw2').value) return flash('Passwords do not match.', 'er');
    const { error } = await sb.auth.updateUser({ password: pw }); if (error) return flash(error.message, 'er');
    e.target.reset(); flash('Password updated.'); });
  $('#logoutBtn').onclick = $('#logout2').onclick = logout;
  sb.auth.onAuthStateChange(ev => { if (ev === 'SIGNED_OUT') location.replace('auth.html#signin'); });
}
