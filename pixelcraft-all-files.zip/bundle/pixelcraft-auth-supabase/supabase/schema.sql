-- PixelCraft Studio: run this whole file once in Supabase > SQL Editor.
-- Passwords are handled entirely by Supabase Auth (bcrypt-hashed in auth.users); nothing here stores them.

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text, full_name text, phone text,
  role text not null default 'client' check (role in ('client','admin')),
  created_at timestamptz not null default now()
);

create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, email, full_name, phone)
  values (new.id, new.email, left(coalesce(new.raw_user_meta_data->>'full_name',''),100), left(coalesce(new.raw_user_meta_data->>'phone',''),20));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create function public.is_admin() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
$$;

create table public.project_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  website_type text not null check (char_length(website_type) <= 80),
  budget text check (char_length(budget) <= 80),
  business_name text check (char_length(business_name) <= 120),
  details text not null check (char_length(details) between 10 and 4000),
  status text not null default 'pending' check (status in ('pending','in_review','accepted','in_progress','completed','rejected')),
  created_at timestamptz not null default now()
);
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  request_id uuid references public.project_requests(id) on delete set null,
  title text not null, amount numeric(12,2) not null default 0,
  status text not null default 'unpaid' check (status in ('unpaid','paid','refunded')),
  created_at timestamptz not null default now()
);
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null, body text, is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.inquiries (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) <= 100), email text not null check (char_length(email) <= 254),
  whatsapp text check (char_length(whatsapp) <= 30), business text check (char_length(business) <= 120),
  website_type text check (char_length(website_type) <= 80), budget text check (char_length(budget) <= 80),
  details text not null check (char_length(details) <= 4000), created_at timestamptz not null default now()
);
create table public.portfolio_projects (
  id uuid primary key default gen_random_uuid(),
  title text not null, category text not null, description text, image_url text, live_url text,
  created_at timestamptz not null default now()
);
create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  name text not null check (char_length(name) <= 100),
  rating int not null check (rating between 1 and 5),
  body text not null check (char_length(body) between 5 and 800),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

-- Row Level Security on everything
alter table public.profiles enable row level security;
alter table public.project_requests enable row level security;
alter table public.orders enable row level security;
alter table public.notifications enable row level security;
alter table public.inquiries enable row level security;
alter table public.portfolio_projects enable row level security;
alter table public.reviews enable row level security;

-- profiles: own row or admin; users may edit only name/phone (role is never user-editable)
create policy "profiles read" on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
create policy "profiles update own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "requests read" on public.project_requests for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "requests insert own" on public.project_requests for insert to authenticated with check (user_id = auth.uid());
create policy "requests admin update" on public.project_requests for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "orders read" on public.orders for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "orders admin write" on public.orders for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "notif read" on public.notifications for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "notif mark read" on public.notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "notif admin insert" on public.notifications for insert to authenticated with check (public.is_admin());

create policy "inquiry insert" on public.inquiries for insert to anon, authenticated with check (true);
create policy "inquiry admin read" on public.inquiries for select to authenticated using (public.is_admin());
create policy "inquiry admin delete" on public.inquiries for delete to authenticated using (public.is_admin());

create policy "portfolio public read" on public.portfolio_projects for select to anon, authenticated using (true);
create policy "portfolio admin write" on public.portfolio_projects for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "reviews read" on public.reviews for select to anon, authenticated using (status = 'approved' or user_id = auth.uid() or public.is_admin());
create policy "reviews insert own" on public.reviews for insert to authenticated with check (user_id = auth.uid());
create policy "reviews admin update" on public.reviews for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "reviews admin delete" on public.reviews for delete to authenticated using (public.is_admin());

-- Column-level privileges: even with a policy, users can only touch the columns listed here
revoke all on all tables in schema public from anon, authenticated;
grant select on public.profiles, public.project_requests, public.orders, public.notifications, public.inquiries to authenticated;
grant update (full_name, phone) on public.profiles to authenticated;
grant insert (website_type, budget, business_name, details) on public.project_requests to authenticated;
grant update (status) on public.project_requests to authenticated;          -- policy limits this to admins
grant insert, update, delete on public.orders to authenticated;              -- policy limits this to admins
grant update (is_read) on public.notifications to authenticated;
grant insert (user_id, title, body) on public.notifications to authenticated; -- policy limits this to admins
grant insert on public.inquiries to anon, authenticated;
grant delete on public.inquiries to authenticated;                           -- policy limits this to admins
grant select on public.portfolio_projects to anon, authenticated;
grant insert, update, delete on public.portfolio_projects to authenticated;  -- policy limits this to admins
grant select on public.reviews to anon, authenticated;
grant insert (name, rating, body) on public.reviews to authenticated;
grant update (status) on public.reviews to authenticated;                    -- policy limits this to admins
grant delete on public.reviews to authenticated;                             -- policy limits this to admins

-- AFTER you sign up on the site and verify your email, make yourself the admin (only possible here in SQL):
-- update public.profiles set role = 'admin' where email = 'youryash23@gmail.com';
